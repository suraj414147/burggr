// ES6-compatible: using const, let, arrow functions, template literals, etc.
const ingredients = [
  "Lettuce",
  "Tomato",
  "Cheese",
  "Onion",
  "Beef Patty",
  "Chicken Patty",
  "Bacon",
  "Pickles",
  "Mayo",
  "Ketchup"
];

let burger = [];

// DOM Manipulation
const ingredientOptions = document.getElementById("ingredientOptions");
const burgerStack = document.getElementById("burgerStack");

// Display ingredient options
const renderIngredients = () => {
  ingredientOptions.innerHTML = "";
  ingredients.forEach((ingredient) => {
    const li = document.createElement("li");
    li.textContent = ingredient;
    li.addEventListener("click", () => addIngredient(ingredient));
    ingredientOptions.appendChild(li);
  });
};

// Add ingredient to burger stack
const addIngredient = (ingredient) => {
  burger.push(ingredient);
  renderBurger();
};

// Remove ingredient from stack when clicked
const renderBurger = () => {
  burgerStack.innerHTML = "";
  burger.forEach((ingredient, index) => {
    const li = document.createElement("li");
    li.textContent = ingredient;
    li.addEventListener("click", () => removeIngredient(index));
    burgerStack.appendChild(li);
  });
};

// Higher-order function to remove by index
const removeIngredient = (index) => {
  burger = burger.filter((_, i) => i !== index); // Higher Order Function: filter
  renderBurger();
};

// Clear all ingredients
const clearBurger = () => {
  burger = [];
  renderBurger();
};

// Submit burger
const submitBurger = () => {
  if (burger.length === 0) {
    alert("Please add ingredients to build your burger!");
    return;
  }

  const finalBurger = burger.join(", ");
  alert(`Your burger includes: ${finalBurger}`);
  clearBurger();
};

// Initialize
renderIngredients();
